## VOTE

Vote is an android app for casting vote on any category.

*It's in production phase for a student of Final Year for project submission. 

##Vision

Idea behind this project is to make an android application using Android studio, Firebase
And Material design guidelines in an under 10 days.

Application should be able to authenticate person through OTP verification.

User will have their personalize screen and they can poat their own polls using text and images.

User can only cast vote on one category only once.

After casting vote, user will be able to see it's Ratings.

User can share their polls using in-built share options.
